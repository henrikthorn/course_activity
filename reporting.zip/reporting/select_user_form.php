<?php

class select_user_form extends moodleform {

    protected function definition() {

    }

    function validation($data, $files) {
        return array();
    }
}