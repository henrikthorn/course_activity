<?php

$plugin->version  = 2016040800;   // The (date) version of this plugin
$plugin->requires = 2010021900;   // Requires this Moodle version
